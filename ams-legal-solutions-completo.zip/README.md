# AMS Legal Solutions

## Uso local con XAMPP

1. Inicia Apache y MySQL desde XAMPP.
2. Importa `database.sql` en phpMyAdmin para crear la base `ams_legal`.
3. Abre `http://localhost/ams-legal-solutions/`.

## Panel administrativo

El panel permite editar datos generales, contacto, portada, firma, áreas legales, abogados, imágenes y SEO.

1. Abre el enlace privado de configuración inicial indicado al entregar el proyecto.
2. Crea un usuario y una contraseña de al menos 12 caracteres.
3. Después ingresa desde `/admin/login.php`.

Las tablas `admin_users` y `site_settings` se crean automáticamente. También están declaradas en `database.sql` para instalaciones manuales.

## Despliegue en Hostinger

- Sube todo el proyecto dentro de `public_html`.
- Verifica las credenciales de producción en `includes/database.php`.
- Confirma que PHP tenga permisos de escritura sobre `uploads/`.
- Crea inmediatamente el primer administrador usando el enlace privado.
- Elimina o cambia el token de configuración después de crear el administrador si el archivo se distribuye a terceros.
