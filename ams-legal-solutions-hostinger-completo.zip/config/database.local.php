<?php
// Configuraci?n privada compartida por el sitio y /admin.
return array (
  'local' => 
  array (
    'host' => 'localhost',
    'name' => 'ams_legal',
    'user' => 'root',
    'pass' => '',
  ),
  'production' => 
  array (
    'host' => 'localhost',
    'name' => 'u564821758_ams_legal',
    'user' => 'u564821758_admin',
    'pass' => '5#zVN3H56Cqd',
  ),
);
